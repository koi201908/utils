/**
 * Alipay.com Inc.
 * 当面付：扫码支付
 * Copyright (c) 2004-2014 All Rights Reserved.
 */
package com.kotei.hemap.common.pay;

import java.text.SimpleDateFormat;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.request.AlipayTradeCancelRequest;
import com.alipay.api.request.AlipayTradePrecreateRequest;
import com.alipay.api.response.AlipayTradeCancelResponse;
import com.alipay.api.response.AlipayTradePrecreateResponse;
import com.alipay.factory.AlipayAPIClientFactory;
import com.kotei.hemap.common.AppSetting;
import com.kotei.hemap.common.utils.LogUtil;
import com.kotei.hemap.common.utils.PropUtil;

/**
 * 支付交易工具类
 * @author weih535
 *
 */
public class PayUtil {

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
	
		
		//201504210011041195
		String out_trade_no="20150528207426"; //商户唯一订单号
		String total_amount="0.01";
		String subject = "测试扫码付订单";
		
		qrPay(out_trade_no,total_amount,subject);
	}
	
	
	/**
	 * 支付宝扫码支付
	 * @param out_trade_no
	 * @param auth_code
	 * @author jinlong.rhj
	 * @date 2015年4月28日
	 * @version 1.0
	 * @return 
	 */
	public static AlipayTradePrecreateResponse qrPay(String out_trade_no,String total_amount,String subject) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		//String time_expire= sdf.format(System.currentTimeMillis()+24*60*60*1000);
		int expireseconds = Integer.parseInt(PropUtil.getInstance().getProperty("AliPay_expire_second"));
		String time_expire= sdf.format(System.currentTimeMillis()+ expireseconds*1000);
		
		StringBuilder sb = new StringBuilder();
		sb.append("{\"out_trade_no\":\"" + out_trade_no + "\",");
		sb.append("\"total_amount\":\""+total_amount+"\",\"discountable_amount\":\"0.00\",");
		sb.append("\"subject\":\""+subject+"\",\"body\":\"test\",");
		//sb.append("\"goods_detail\":[{\"goods_id\":\"apple-01\",\"goods_name\":\"ipad\",\"goods_category\":\"7788230\",\"price\":\"88.00\",\"quantity\":\"1\"},{\"goods_id\":\"apple-02\",\"goods_name\":\"iphone\",\"goods_category\":\"7788231\",\"price\":\"88.00\",\"quantity\":\"1\"}],");
		sb.append("\"operator_id\":\"op001\",\"store_id\":\"pudong001\",\"terminal_id\":\"t_001\",");
		sb.append("\"time_expire\":\""+time_expire+"\"}");
		System.out.println(sb.toString());

		AlipayClient alipayClient = AlipayAPIClientFactory.getAlipayClient();
		

		// 使用SDK，构建群发请求模型
		AlipayTradePrecreateRequest request = new AlipayTradePrecreateRequest();
		request.setBizContent(sb.toString());
		request.setNotifyUrl(AppSetting.APP_URL + PropUtil.getInstance().getProperty("NotifyUrl"));
//		request.putOtherTextParam("ws_service_url", "http://unitradeprod.t15032aqcn.alipay.net:8080");
		AlipayTradePrecreateResponse response = null;
		try {

			// 使用SDK，调用交易下单接口
			response = alipayClient
					.execute(request);

			System.out.println(response.getBody());
			System.out.println(response.isSuccess());
			System.out.println(response.getMsg());
			
			
			// 这里只是简单的打印，请开发者根据实际情况自行进行处理
			/*if (null != response && response.isSuccess()) {
				if (response.getCode().equals("10000")) {
					System.out.println("商户订单号："+response.getOutTradeNo());
					System.out.println("二维码值："+response.getQrCode());//商户将此二维码值生成二维码，然后展示给用户，用户用支付宝手机钱包扫码完成支付
					//二维码的生成，网上有许多开源方法，可以参看：http://blog.csdn.net/feiyu84/article/details/9089497
					
				} else {

				//打印错误码
				System.out.println("错误码："+response.getSubCode());
				System.out.println("错误描述："+response.getSubMsg());
				}
			}*/
		} catch (Exception e) {
			LogUtil.error(e);
		}
		
		return response;
	}
	
	
	/**
	 * 撤销订单
	 * 
	 * @param out_trade_no
	 * @author jinlong.rhj
	 * @date 2015年4月28日
	 * @version 1.0
	 * @return
	 */
	public static AlipayTradeCancelResponse cancelOrder(
			final String out_trade_no) {
		AlipayClient alipayClient = AlipayAPIClientFactory.getAlipayClient();
		AlipayTradeCancelRequest request = new AlipayTradeCancelRequest();
		String biz_content = "{\"out_trade_no\":\"" + out_trade_no + "\"}";
		request.setBizContent(biz_content);
		AlipayTradeCancelResponse response = null;

		try {
			response = alipayClient.execute(request);

			System.out.println(response.getBody());
			System.out.println(response.isSuccess());
			System.out.println(response.getMsg());
			System.out.println(response.getAction());
			System.out.println(response.getCode());
			System.out.println(response.getErrorCode());
			System.out.println(response.getOutTradeNo());
			System.out.println(response.getRetryFlag());
			System.out.println(response.getSubCode());
			System.out.println(response.getSubMsg());
			System.out.println(response.getTradeNo());

			if (null != response && response.isSuccess()) {
				if (response.getCode().equals("10000")) {

					
				} else {
					// 没有撤销成功，需要重试几次

					
					if (response.getRetryFlag().equals("Y")) {
						// 如果重试标识为Y，表示支付宝撤销失败，需要轮询重新发起撤销
						cancelOrderRetry(out_trade_no);
					}
				}
			}
		} catch (AlipayApiException e) {
			LogUtil.error(e);
		}
		return response;
	}

	/**
	 * 轮询发起撤销重试
	 * 
	 * @param out_trade_no
	 * @author jinlong.rhj
	 * @date 2015年4月28日
	 * @version 1.0
	 */
	public static void cancelOrderRetry(final String out_trade_no) {
		final AlipayClient alipayClient = AlipayAPIClientFactory.getAlipayClient();
		final AlipayTradeCancelRequest request = new AlipayTradeCancelRequest();
		String biz_content = "{\"out_trade_no\":\"" + out_trade_no + "\"}";
		request.setBizContent(biz_content);

		// 子线程异步方式，每个10秒钟重试一次，重试5次,加上重试前的1次，总共6次1分钟
		new Thread(new Runnable() {
			int i = 0;
			int n = 5;

			@Override
			public void run() {
				// TODO Auto-generated method stub

				while (++i <= n) {
					try {
						Thread.sleep(10000);
						System.out.println("重试撤销请求 第 " + i + " 次");
						AlipayTradeCancelResponse response = alipayClient
								.execute(request);

						System.out.println(response.getBody());
						System.out.println(response.isSuccess());
						System.out.println(response.getMsg());

						if (null != response && response.isSuccess()) {
							if (response.getCode().equals("10000")
									&& response.getBody().contains(
											"\"retry_flag\":\"N\"")) {
								break;
							}
						}

						if (i == n) {
							// 处理到最后一次，还是未撤销成功，需要在商户数据库中对此单最标记，人工介入处理

						}

					} catch (AlipayApiException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}
		}).start();

	}
	/*
	*//** 支付中订单存储  key:outTradeNo, value:orderNo **//*
	private static HashMap<String, Order> unClosedOrdersMap = new HashMap<String, Order>();
	
	*//** 存入订单 **//*
	public static void saveOrderNo(String outTradeNo, Order order){
		if(!unClosedOrdersMap.containsKey(outTradeNo)){
//			System.out.println("+++++ trade saved:" + value + "+++++++++++");
			unClosedOrdersMap.put(outTradeNo, order);
		}
	}
	*//** 移除订单  **//*
	public static void removeOrderNo(String outTradeNo){
		if(unClosedOrdersMap.containsKey(outTradeNo)){
//			System.out.println("+++++++++++removed:" + sentValidateKeys.get(userid) + "+++++++++++");
			unClosedOrdersMap.remove(outTradeNo);
		}
	}
	*//** 取得该交易的原始订单号 **//*
	public static Order getOrderNo(String outTradeNo){
		return unClosedOrdersMap.get(outTradeNo);
	}*/

}
