package com.kotei.hemap.common.exception;

public class KtVendExceptoin extends RuntimeException {
	private String myMsg = "";
	private static final long serialVersionUID = -6381294134782325976L;

	public KtVendExceptoin() {
		super();
	}

	public KtVendExceptoin(String message, Throwable cause) {
		super(cause.getMessage(), cause);
		this.myMsg = message;
	}

	public KtVendExceptoin(String message) {
		super(message);
	}

	public KtVendExceptoin(Throwable cause) {
		super(cause);
	}

	public String getMyMsg() {
		return myMsg;
	}

	
}
