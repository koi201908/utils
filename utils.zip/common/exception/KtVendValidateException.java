package com.kotei.hemap.common.exception;

public class KtVendValidateException extends KtVendExceptoin {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public KtVendValidateException() {
		super();
	}

	public KtVendValidateException(String message, Throwable cause) {
		super(message, cause);
	}

	public KtVendValidateException(String message) {
		super(message);
	}

	public KtVendValidateException(Throwable cause) {
		super(cause);
	}
}
