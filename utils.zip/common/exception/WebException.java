package com.kotei.hemap.common.exception;

public class WebException extends Exception {

	private static final long serialVersionUID = 8762967765987401562L;

	public WebException(String msg) {
		super(msg);
	}
	
	public WebException(Throwable throwable) {
		super(throwable);
	}
	
	public WebException(String msg, Throwable throwable) {
		super(msg, throwable);
	}
	
}
