package com.kotei.hemap.common.utils;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

import javax.imageio.ImageIO;

public class TestBitmapSerialize {

	public static void main(String[] args){
		File f = new File("c:\\木兰天池1.jpg");
		
		try {
			if (f.exists()) {
//				BufferedImage bi = ImageIO.read(f);
				BufferedInputStream in = new BufferedInputStream(new FileInputStream(f));
				byte[] imgdata = new byte[(int)f.length()];
				if(in.read(imgdata)>0){
					String encodeString = Base64Utils.encodeBase64(imgdata);
//					System.out.println(encodeString);
					//Base64编码
					Base64Utils.saveEncodeStringToFile(encodeString, "c:\\base64.txt");
					
					//把Base64还原成另一张图片
					byte[] newImage = Base64Utils.decodeBase64(encodeString);
					if(newImage!=null && newImage.length > 0){
						ImageUtils.writeImageFile(newImage, "c:\\base64Image.jpg");
					}else{
						System.out.println("decode failure...");
					}
				}
				
				in.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
