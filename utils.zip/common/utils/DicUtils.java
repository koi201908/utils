package com.kotei.hemap.common.utils;

import java.util.HashMap;

public class DicUtils {
	private HashMap<Integer, HashMap<Integer, String>> dics = null;

	public void setDics(HashMap<Integer, HashMap<Integer, String>> dics) {
		this.dics = dics;
	}

	public DicUtils(HashMap<Integer, HashMap<Integer, String>> dics) {
		this.dics = dics;
	}
	
	/** 获取出入库类别 **/
	public HashMap<Integer, String> getStorageTypes(){
		return dics.get(10);		
	} 
	
	/** 获取出入库单据类别 **/
	public HashMap<Integer, String> getStorageReceiptTypes(){
		return dics.get(14);		
	}
	
	/** 获取库存单位 **/
	public HashMap<Integer, String> getStockUnits(){
		return dics.get(17);		
	}
	
	/** 获取支付类别 **/
	public HashMap<Integer, String> getPaytypes(){
		return dics.get(50);		
	}
	
	/**
	 * 获取行政区域子类别
	 * @param parentAreaId 父区域Id，如果为100的话表示首层行政区域（省）
	 * @return
	 */
	public HashMap<Integer, String> getArea(Integer parentAreaId){
		return dics.get(parentAreaId);		
	}
			
}
