package com.kotei.hemap.common.utils;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/*
 *  JsonUtil类
 *  
 *  普通类型、List、Collection等都是用JSONArray解析
 *  
 *  Map、自定义类型是用JSONObject解析
 * 
 * 1.JSONObject是一个name:values集合，通过它的get(key)方法取得的是key后对应的value部分(字符串)
 *         通过它的getJSONObject(key)可以取到一个JSONObject，--> 转换成map,
 *         通过它的getJSONArray(key) 可以取到一个JSONArray ，
 * 
 * 
 */
public class JsonUtil {

	/**
	 * 将Java对象、数组或集合转换成json字串。不支持Map。
	 * @param obj
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static String objectToJson(Object obj) {
		if (obj == null) {
			return "";
		}
		Class cls = obj.getClass();
		if(cls.isArray() || obj instanceof Collection){
			return JSONArray.fromObject(obj).toString();
		}
		return JSONObject.fromObject(obj).toString();
	}
	
	/**
	 * 将Json对象或数组的字符串转换成Java对象、数组或集合。不支持Map。
	 * 如果要转成的类中含有List等集合，请传入map
	 *  Map classMap = new HashMap();
	 *  classMap.put("list", Person.class);
	 * @param strjson
	 * @param cls
	 * @param objType  0:Normal Object 1:Array  2:Collection
	 * @param map 如果要转成的类中含有List等集合，请传入map
	 * @return
	 */
	public static <T,P> Object jsonToObj(String strjson, Class<T> cls, int objType, Map<String, Class<P>> map) {
		if (strjson == "") {
			return null;
		}
		if(objType==1){
			System.out.println("----to Array----");
			JSONArray jsonArray = JSONArray.fromObject(strjson);
			return jsonArray.toArray();
		}
		if(objType==2){
			System.out.println("----to Collection----");
			JSONArray jsonArray = JSONArray.fromObject(strjson);
			return JSONArray.toCollection(jsonArray, cls);
		}
		System.out.println("----to normal object----");
		if(null == map){
			return JSONObject.toBean(JSONObject.fromObject(strjson), cls);
		}else {
			return JSONObject.toBean(JSONObject.fromObject(strjson), cls, map);
		}
	}
	/**
	 * Json对象或数组的字符串转换成Java对象、数组或集合。
	 * @param strjson
	 * @param cls
	 * @param objType
	 * @return
	 */
	public static <T,P> Object jsonToObj(String strjson, Class<T> cls, int objType) {
		return jsonToObj(strjson, cls, objType, null);
	}
	
	@SuppressWarnings("unchecked")
	public static <K,V> String mapToJson(Map<K, V> map) {
		if (map == null) {
			return "";
		}
		
		Iterator<K> it = map.keySet().iterator();
		K key = it.next();
		if(!(key instanceof String)){
			Map<String, V> newMap = new LinkedHashMap<String, V>();
			newMap.put(key.toString(), map.get(key));
			while(it.hasNext()) {
				key = it.next();
				newMap.put(key.toString(), map.get(key));
			}
			return doMapToJson(newMap);
		}
		return doMapToJson((Map<String, V>)map);
	}
	
	@SuppressWarnings({ "hiding", "unchecked" })	
	private static <String,V> String doMapToJson(Map<String, V> map) {
		
//		return (String) JSONArray.fromObject(map).toString();
		return (String) JSONObject.fromObject(map).toString();
	}

}
