package com.kotei.hemap.common.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class GZipUtil {
	/**
	 * 读取Gzip压缩流
	 * @param b
	 * @return
	 * @throws IOException
	 */
	public static byte[] readGZipBytes(byte[] b) throws IOException{
		int bufsize = 1024;
		byte[] buf=new byte[1024];
		
		//将gzip压缩流读入到内存中
		ByteArrayInputStream byteIn = new ByteArrayInputStream(b);
		GZIPInputStream gzipIn = new GZIPInputStream(byteIn, bufsize);
		
		//将解压缩的流写入到字节输出流
		ByteArrayOutputStream byteOut = new ByteArrayOutputStream(bufsize);		
		int readnum = 0;
		while((readnum = gzipIn.read(buf, 0, buf.length)) != -1){
			byteOut.write(buf, 0, readnum);
		}
		
		byte[] rtnBytes = byteOut.toByteArray();
		byteOut.close();
		gzipIn.close();
		
		return rtnBytes;
		
	}
	
	/**
	 * 建立Gzip压缩输出流
	 * @param b
	 * @return
	 * @throws IOException
	 */
	public static byte[] writeGZipBytes(byte[] b) throws IOException{
		int bufsize = 1024;
		
//		//将
//		InputStream byteIn = new ByteArrayInputStream(b);
//		byte[] buf = new byte[bufsize];
//		BufferedInputStream bufIn = new BufferedInputStream(byteIn, 3 * bufsize);

		//用GZIPOutputStream把输入的字节数组写到压缩输出流中
		ByteArrayOutputStream byteOut = new ByteArrayOutputStream(bufsize);
		//如果包装文件输出流，则是输出到文件
		GZIPOutputStream gzipOut = new GZIPOutputStream(byteOut); 
		
		gzipOut.write(b);
		gzipOut.flush();
		gzipOut.close();
		
		return byteOut.toByteArray();
	}
}
