package com.kotei.hemap.common.utils;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.util.ServletContextAware;

public class ScopeUtils implements ServletRequestAware, ServletResponseAware, ServletContextAware{
	private HttpServletRequest request; 
	private ServletContext servletContext; 
	private HttpServletResponse response; 
	
	public HttpServletRequest getRequest() {
		return request;
	}

	public ServletContext getServletContext() {
		return servletContext;
	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setServletRequest(HttpServletRequest req) {
		this.request = req;
	}

	public void setServletResponse(HttpServletResponse res) {
		this.response = res;
	}

	public void setServletContext(ServletContext ser) {
		this.servletContext = ser;
	}
	
}
