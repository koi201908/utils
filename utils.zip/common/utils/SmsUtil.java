package com.kotei.hemap.common.utils;

import com.kotei.hemap.common.exception.KtVendExceptoin;

public class SmsUtil {
	/** 绑定手机验证码 **/
	public static final int SMSTYPE_VALIDATE = 1;	//验证码
	/** 密码通知 **/
	public static final int SMSTYPE_GETPWD = 2;		//找回密码
	/**
	 * 发送短信验证码或通知
	 * @param phoneNo
	 * @param smsType 短信通知类别： 1-验证码  2-找回密码通知
	 * @param conteString 与短信模板相匹配的参数1: 验证码或密码
	 * @param params 与短信模板相匹配的参数2
	 * @return
	 */
	public static boolean sendSMS(String phoneNo,  int smsType, String conteString, String param2){
		/**
		 * 1、短信验证码发送的模板内容为“亲爱的用户， 您的验证码是{1}，请于{2}秒钟内正确输入”
		 * 2、找回密码时的短信通知内容为：“您的密码是{1}，请您妥善保管好您的密码。“
		 */
		if(smsType!=SMSTYPE_VALIDATE && smsType!=SMSTYPE_GETPWD) 
			throw new KtVendExceptoin("无效的短信通知类型："+smsType);
		
		String tempId="";
		//根据类型设置短信模板ID及参数
		if(smsType==SMSTYPE_VALIDATE){
			tempId= PropUtil.getInstance().getProperty("SMS_TEMPID");
			param2 = PropUtil.getInstance().getProperty("SMS_EXPIRE");
		}else {
			tempId= PropUtil.getInstance().getProperty("SMS_TEMPID_GETPWD");
		}
		String[] params = null;
		if(AppUtils.isEmpty(param2)){
			params = new String[]{conteString};
		}else{
			params = new String[]{conteString, param2};
		}
		
		if(SendTemplateSMSBySDK.sendTemplateSMS(phoneNo, tempId, params)){
			//正常返回输出
			LogUtil.info(LogUtil.INFO_COMMON + "Sent SMS_Validate Success!smsType=" + smsType);
			return true;
		}else {
			LogUtil.error("[Send SMS ERROR:]smsType=" + smsType);
			return false;
		}
	}
	
	
}
