package com.kotei.hemap.common.utils;

import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.util.List;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;



//一、将网页资料以excel报表以线上浏览方式呈现 
//<%@ page c %>
//
//线上浏览的方式： response.setHeader("Content-disposition","inline; filename=test1.xls"); 
//下载的方式： response.setHeader("Content-disposition","attachment; filename=test2.xls");
//<html>内容</html>

//二、输出到客户端
//response.reset();
//response.setContentType("application/vnd.ms-excel");
//ExcelCreator.writeExcel(response.getOutputStream(),ResultSet);
public class ExcelCreator {
	 // 写入Excel的Writer对象
    private BufferedOutputStream writer=  null;
	private Element configRoot;
    private static String CONFIG_FILE_NAME =  "csvConfig.xml";
    private Element configNode;
    
//    //分隔符
    private char TAB = '\t';        
    private char COMMA = ',';
	private String strConfigNode;
    

    public ExcelCreator(OutputStream writer) throws Exception{
    	this.writer = new BufferedOutputStream(writer);
    	initconfig();
    }
    private void initconfig() throws Exception{
    	SAXBuilder sb = new SAXBuilder();
    	if(!CONFIG_FILE_NAME.trim().equals("")){
	    	try{
	    		URI uri = new URI(getClass().getClassLoader().getResource(CONFIG_FILE_NAME).getPath());
	    		InputStream in = new FileInputStream(uri.getPath());
//	    		InputStream is = this.getClass().getResourceAsStream(CONFIG_FILE_NAME);
	    		Document doc = sb.build(in);
	    		configRoot = doc.getRootElement();    		
	    	}catch(Exception e){
	    		LogUtil.error(e, "请指定正确的csvConfig.xml路径");
	    		throw e;
	    	}
    	}
    }
    
    @SuppressWarnings("rawtypes")    
	public void doExcel(List rs, String configNodeString) throws Exception{
		if(configNodeString!=null && !configNodeString.equals("")){
			this.configNode = configRoot.getChild(configNodeString);
			this.strConfigNode = configNodeString;
			if(CONFIG_FILE_NAME.equals(""))
				throw new RuntimeException("config file is not defined! Specify config file name first!");
			writeBOM();
			writeHeader();
			writeContentByConfig(rs);
		}
    	writer.flush();
    	writer.close();
    }
    
    
	@SuppressWarnings("rawtypes")
	private void writeContentByConfig(List rs) throws Exception{
		Element efields = configNode.getChild("Field");
		if(efields==null) throw new RuntimeException(this.strConfigNode + "'s <Label> node is null!");
		String[] fields = efields.getText().split(",");

		for(Object item: rs){
			PropertyDescriptor[] props = Introspector.getBeanInfo(item.getClass()).getPropertyDescriptors();
			for(int i=0; i< fields.length; i++){
				String field = fields[i];
				for(PropertyDescriptor prop:props){
					if(prop.getName().equals(field)){
						String fieldValue = "";
						Object obj = prop.getReadMethod().invoke(item, null);
						if(i < fields.length-1){
							fieldValue= obj == null?"" + COMMA: formatString(obj.toString())+COMMA;
						}
						else
							fieldValue=obj == null?"" : formatString(obj.toString());
						writer.write(fieldValue.getBytes("utf-8"));
					}
				}
			}
			writer.write("\n".getBytes("utf-8"));
		}
			
	}
	private void writeBOM() throws Exception{
		writer.write(new byte[] { (byte) 0xEF, (byte) 0xBB, (byte) 0xBF });
	}
	private void writeHeader() throws Exception{
		Element header = configNode.getChild("Label");
		if(header==null) 
			throw new RuntimeException(this.strConfigNode + "'s <Label> node is null!");
		writer.write(header.getText().replace(',', COMMA).getBytes("utf-8"));
		writer.write("\n".getBytes("utf-8"));
    }
    
    private String formatString(String tmp){
        if (tmp.indexOf('\n') != -1)
        {
            tmp = tmp.replace('\n', (char)(127));
        }
        
        if (tmp.indexOf(COMMA) != -1)
        {
            tmp = tmp.replaceAll(String.valueOf(COMMA), "，");
        }
        if (tmp.indexOf('\r') != -1)
        {
            tmp = tmp.replace('\r', (char)(127));
        }
        if (tmp.indexOf('\t') != -1)
        {
            tmp = tmp.replace('\t', (char)(127));
        }
        return tmp;
    }
}
