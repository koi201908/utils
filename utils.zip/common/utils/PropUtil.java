package com.kotei.hemap.common.utils;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.util.Properties;

import com.kotei.hemap.common.AppSetting;

public class PropUtil {
	public static PropUtil instance = new PropUtil();

	public static PropUtil getInstance() {
		return instance;
	}

	static Properties prop;

	public PropUtil() {
		prop = new Properties();
		String configPath = getClass().getClassLoader().getResource("vendingConfig.properties").getPath();
		try {
			URI uri = new URI(configPath);
			System.out.println("getResource path:"+uri.getPath());
			InputStream in = new FileInputStream(uri.getPath());
			prop.load(in);
		} catch (Exception e) {
			LogUtil.error(e);
		}
	}

	public String getProperty(String key) {
		if (null != prop)
			try {
				return new String(prop.getProperty(key).getBytes("ISO-8859-1"),"utf-8");
			} catch (UnsupportedEncodingException e) {
				LogUtil.error(e);
			}
		return "";
	}
	
	public String getAppNewVer_android() {
		return getProperty("ANDROID_APP_NEWVERSIONS");
	}
	public String getAppUpdateUrl_android() {
		return AppSetting.APP_URL + getProperty("ANDROID_APP_UPDATEURL");
	}
	
	
	
	

}
