package com.kotei.hemap.common.utils;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.commons.codec.base64.Base64;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
	  
@SuppressWarnings("deprecation")
public class Base64Utils {  
	
	public static BASE64Encoder encoder = new BASE64Encoder();
	public static BASE64Decoder decoder = new BASE64Decoder();
	
    /**
     * 加密二进制数组
     * @param b
     * @return
     */
	public static String encodeBase64(byte[] b) {  
        if (b != null) {  
        	return encoder.encode(b);
        }  
        return null;  
    }

  
    // 解密  
    public static byte[] decodeBase64(String base64String) throws IOException {  
        if (base64String != null ) {  
	        return decoder.decodeBuffer(base64String); 
	    } 
        return null;
    }  
    
    public static void saveEncodeStringToFile(String base64String, String filePath) 
    		throws IOException {
//    	FileOutputStream out = new FileOutputStream(new File(filePath));
////    	BufferedOutputStream bout = new BufferedOutputStream(out);
//    	out.write(base64String.getBytes());
    	FileWriter out = new FileWriter(new File(filePath));
    	out.write(base64String);
    	out.flush();
    	out.close();
    }
}
