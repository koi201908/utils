package com.kotei.hemap.common.utils;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;

import javax.imageio.ImageIO;

import org.apache.struts2.ServletActionContext;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;

import com.kotei.hemap.common.constant.AppConstants;
import com.kotei.hemap.common.exception.KtVendValidateException;
import com.kotei.hemap.persistence.entity.Menu;


public class AppUtils implements BeanFactoryAware {
	private static BeanFactory beanFactory;  

	public static ArrayList<Menu> getAdminMenus(){
		ArrayList<Menu> menus = new ArrayList<Menu>();
		menus.add(new Menu("首页", "jsp/right.html"));
		menus.add(new Menu("帐户管理", "")
			.addChild(new Menu("帐户一览", "admin_accountManage.action")));
		
		return menus;
	}
	
	/**
	 * 针对WebService调 用是否需要检查登录信息
	 * @param funcid 功能号
	 * @return true:需要检查     false:不需要检查
	 */
	public static boolean isCheckLogin(String funcId){

		return false;
	}
	
	/**
	  * 创建指定数量的随机字符串
	  * @param numberFlag 是否是数字
	  * @param length
	  * @return
	  */
	public static String createRandom(boolean numberFlag, int length) {
		String retStr = "";
		String strTable = numberFlag ? "1234567890"
				: "1234567890abcdefghijkmnpqrstuvwxyz";
		int len = strTable.length();
		boolean bDone = true;
		do {
			retStr = "";
			int count = 0;
			for (int i = 0; i < length; i++) {
				double dblR = Math.random() * len;
				int intR = (int) Math.floor(dblR);
				char c = strTable.charAt(intR);
				if (('0' <= c) && (c <= '9')) {
					count++;
				}
				retStr += strTable.charAt(intR);
			}
			if (count >= 2) {
				bDone = false;
			}
		} while (bDone);

		return retStr;
	}
	

	/** phone app端用户验证码存储器 key:userid, value:validateCode **/
	private static HashMap<String, String> sentValidateKeys = new HashMap<String, String>();
	
	/** 存入验证码 **/
	public static void saveValidateKey(String userid, String value){
		if(!sentValidateKeys.containsKey(userid)){
			LogUtil.info("+++++++++++saved:" + value + "+++++++++++");
			sentValidateKeys.put(userid, value);
		}
	}
	/** 移除验证码 **/
	public static void removeValidateKey(String userid){
		if(sentValidateKeys.containsKey(userid)){
			LogUtil.info("+++++++++++removed:" + sentValidateKeys.get(userid) + "+++++++++++");
			sentValidateKeys.remove(userid);
		}
	}
	/** 取得原始验证码 **/
	public static String getOldValidateKey(String userid){
		return sentValidateKeys.get(userid);
	}

	
	public static boolean isEmpty(String str){
		return (str == null || str.equals(""));
	}
	
	/** 
     * 根据beanName名字取得bean 
     *  
     * @param beanName 
     * @return 
     */  
    @SuppressWarnings("unchecked")
	public static <T> T getBean(String beanName) {  
        if (null != beanFactory) {  
            return (T) beanFactory.getBean(beanName);  
        }  
        return null;  
    }  
	
	@SuppressWarnings("static-access")
	@Override
	public void setBeanFactory(BeanFactory arg0) throws BeansException {
		// TODO Auto-generated method stub
		this.beanFactory = arg0;
	}

	


	/**
	 * 处理sql语句中的参数数组，避免将无效的值插入到数据库中。
	 * 处理1：空字串转为null
	 * 处理2：long型值通常是主键或外键，如果为0则转为null
	 * 处理3：int型值通常是字典数据，如果为0则转为null
	 * @param args
	 * @return
	 */
	public static Object[] dealArgs(Object[] args){
		for(Object value: args){
			if (value!=null && value.getClass().getName().equals(Long.class.getName()) && ((Long)(value)).longValue()==0){
				value = null;
			}
			if (value!=null && value.getClass().getName().equals(Integer.class.getName()) && ((Integer)(value)).intValue()==0){
				value = null;
			}
			if (value!=null && value.getClass().getName().equals(String.class.getName()) && ((String)(value)).equals("")){
				value = null;
			}
//			if (value!=null && value.getClass().getName().equals(Date.class.getName())){
//				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//				value = sdf.format(value);
//			}
		}
		return args;
	}

//	public static String createSqlByCondition(String sql,
//			Map<String, Object> conditionMap) {
//		if(conditionMap == null){
//			return sql;
//		}
//		StringBuffer sb = new StringBuffer(sql + " Where");
//		Object[] strCons = (Object[])conditionMap.get(AppKeys.CONDITION);
//		for (Object con : strCons) {
//			sb.append(" " + con + "=? and");
//		}
//		String rsql = sb.toString();
//		return rsql.substring(0,rsql.length()-3);
//	}
	
	/**
	 * 日期比较
	 * @param date1
	 * @param date2
	 * @return 1: 1>2  2: 1<2 3: 1=2 
	 * @throws KtVendValidateException
	 */
	public static int compareDate(Date date1, Date date2){
		long l1 = date1.getTime();
		long l2 = date2.getTime();
		if(l1 > l2)
			return 1;
		if(l1 < l2)
			return 2;
		return 0;
	}
	
	/**
	 * 
	 * @param date1
	 * @param date2
	 * @return 1: 1>2  2: 1<2 3: 1=2 
	 * @throws KtVendValidateException
	 */
	public static int compareDate(String date1, String date2) throws KtVendValidateException{
		try {
			SimpleDateFormat parseTime = new SimpleDateFormat(
					"yyyy-MM-dd hh:mm:ss");
			Date d1 = parseTime.parse(date1);
			Date d2 = parseTime.parse(date2);
			long l1 = d1.getTime();
			long l2 = d2.getTime();
			if(l1 > l2)
				return 1;
			if(l1 < l2)
				return 2;
			return 0;
			
		} catch (Exception e) {
			throw new KtVendValidateException(e);
		}

	}
	
	/**
	 * 对日期的指定部分进行加算操作,返回格式化后的新日期字串
	 * @param date
	 * @param field
	 * @param amount
	 * @param formatPattern 返回日期字串的格式
	 */
	public static String dateTimeAdd(Date date, int field, int amount, String formatPattern){
		GregorianCalendar gc =new GregorianCalendar();
		SimpleDateFormat sf  =new SimpleDateFormat(formatPattern);
		gc.setTime(date);
		gc.add(field, amount);
		return sf.format(gc.getTime());
	}	

	/**
	 * 对日期的指定部分进行加算操作,返回新的日期
	 * @param date
	 * @param field
	 * @param amount
	 * @return
	 */
	public static Date dateTimeAdd(Date date, int field, int amount){
		GregorianCalendar gc =new GregorianCalendar();
		gc.setTime(date);
		gc.add(field, amount);
		return gc.getTime();
	}
	
	/**
	 * 图片上传
	 * @param image 要上传的图片文件
	 * @param imageFileName 要上传的图片文件名称
	 * @param uploadPath 要上传的路径
	 * @param excludeFlg 是否不对图片进行等比处理
	 */
	public static String imageUpload(File image, String imageFileName, String oldImageName, String uploadPath, boolean excludeFlg) throws Exception{
		String realpath = ServletActionContext.getServletContext().getRealPath("/"+uploadPath);
		
		if (!"".equals(oldImageName) && oldImageName != null) {
			// 删除旧图片
			File oldImage = new File(new File(realpath), oldImageName);
			oldImage.delete();
		}
		
		// 构造上传图片的名称
		String curtime = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
		String newImageName = curtime + "_" + imageFileName;
		String newImageSuffix = newImageName.substring(newImageName.lastIndexOf(".") + 1);
		
		// 对要上传的新图片进行等比压缩或放大的处理并生成新的图片到缓存中
		BufferedImage bi3 = processImage(image, excludeFlg);
				
		// 将缓存中的图片上传
		File newImage = new File(new File(realpath), newImageName);
        if (!newImage.getParentFile().exists())
            newImage.getParentFile().mkdirs();
		//构造IO流输出到文件
		FileOutputStream fos = new FileOutputStream(newImage);
		ImageIO.write(bi3, newImageSuffix, fos);
		bi3.flush();
		fos.close();
		return newImageName;
	}
	
	/**
	 * 对图片文件进行等比压缩，放大处理
	 * @param image 要处理的图片
	 * @param excludeFlg 是否不对图片进行等比处理
	 */
	public static BufferedImage processImage(File image, boolean excludeFlg) throws IOException {
		// 取得上传图片规定的宽度
		int standwidth = Integer.parseInt(PropUtil.getInstance().getProperty("shopping.imgwidth"));
		//读取图片
		BufferedImage bi = ImageIO.read(image);
		int newWidth  = 0;
		int newHeight  = 0;
		if (excludeFlg == false) {
			newWidth = standwidth;
			newHeight = (int)( bi.getHeight() * ((float) standwidth / (float)(bi.getWidth())));
		} else {
			newWidth = bi.getWidth();
			newHeight = bi.getWidth();
		}
		
		Image image2 = bi.getScaledInstance(newWidth, newHeight, Image.SCALE_AREA_AVERAGING);
		//获取压缩后图片的高和宽
		int aftHeight = image2.getHeight(null);
		int aftWidth = image2.getWidth(null);
		//以新的高和宽构造一个新的缓存图片
		BufferedImage bi3 = new BufferedImage(aftWidth, aftHeight, BufferedImage.TYPE_INT_RGB);
		Graphics g = bi3.getGraphics();
		//在新的缓存图片中画图
		g.drawImage(image2, 0, 0, null);
		return bi3;
	}
	
	/**
	 * 检测是否是图片文件
	 */
	public static boolean isImageFile(String imageFileName) {
		boolean isImage = false;
        String[] imgExts = {".gif", ".jpg", ".jpeg", ".png"};
        for(String ext : imgExts) {
            if(imageFileName.toLowerCase().endsWith(ext)) {
                isImage = true;
            }
        }
        return isImage;
	}
	
	/**
	 * 检测图片大小是否符合要求
	 * @param imageFile 要check的图片
	 * @param procFlg check标准的标示 1：管理员头像图片标准 2：商品信息图片标准
	 */
	public static boolean checkImageSize(File imageFile, String procFlg) {
		boolean rtn = false;
		// 取得上传文件规定的大小值
		long stdLength = 0L;
		if ("2".equals(procFlg)) {
			stdLength = Long.parseLong(PropUtil.getInstance().getProperty("shopping.imgSizeLimit"));
			// 判断大小是否小于规定值
			long length = imageFile.length();
			if ((length/1024) < stdLength) {
				return true;
			}
		}
		if("1".equals(procFlg)){
			stdLength = Long.parseLong(PropUtil.getInstance().getProperty("account.imgSizeLimit"));
			// 判断大小是否小于规定值
			long length = imageFile.length();
			if ((length/1024) < stdLength) {
				return true;
			}
		}
		return rtn;
	}
}
