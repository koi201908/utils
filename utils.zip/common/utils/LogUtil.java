package com.kotei.hemap.common.utils;

import org.apache.log4j.Logger;

public class LogUtil {
	
	public static final String WS = "[DoWebService]";
	public static final String DEBUG_IN = "[TRACEINFO][IN]";
	public static final String DEBUG_PARAMIN = "[TRACEINFO][PARAMIN]";
	public static final String DEBUG_PARAMOUT = "[TRACEINFO][PARAMOUT]";
	public static final String DEBUG_MSGTO = "[TRACEINFO][MSG_TO]";
	public static final String INFO_LOGIN = "[DEBINFO][Login]";
	public static final String INFO_TRAD = "[DEBINFO][TRAD]";
	public static final String INFO_MQTT = "[DEBINFO][MQTT]";
	public static final String INFO_COMMON = "[DEBINFO][COMMON]";
	public static final String INFO_LOGOUT = "[DEBINFO][Logout]";
	public static final String ERR = "[ERRINFO]";
	public static final String EXCEPTION = "[ERR_EXCEPTION]";
	
	public static final String WS_DEBUG_IN = WS + "[TRACEINFO][IN]";
	public static final String WS_DEBUG_PARAMIN = WS + "[TRACEINFO][PARAMIN]";
	public static final String WS_DEBUG_PARAMOUT = WS + "[TRACEINFO][PARAMOUT]";
	public static final String WS_DEBUG_MSGTO = WS + "[TRACEINFO][MSG_TO]";
	public static final String WS_INFO_LOGIN = WS + "[DEBINFO][Login]";
	public static final String WS_INFO_LOGOUT = WS + "[DEBINFO][Logout]";
	public static final String WS_INFO_TRAD = WS + "[DEBINFO][TRAD]";
	public static final String WS_INFO_MQTT = WS + "[DEBINFO][MQTT]";
	public static final String WS_INFO_COMMON = WS + "[DEBINFO][COMMON]";	
	public static final String WS_ERR = WS + "[ERRINFO]";
	public static final String WS_EXCEPTION = WS + "[ERR_EXCEPTION]";
	
	
	static Logger log = Logger.getLogger(LogUtil.class);
	
	public static void info(Object message){
		log.info(message);
	}
	public static void warn(Object message){
		log.warn(message);
	}
	
	public static void debug(Object message){
		log.debug(message);
	}
	
	public static void error(Object message){
		log.error(message);
	}
	
	/** 输出原始消息 + stackTrace **/
	public static void error(Exception e){
		log.error(EXCEPTION + e.getMessage(), e);
	}
	
	/**
	 * 输出自定义消息 + stackTrace
	 * @param e
	 * @param message
	 */
	public static void error(Exception e, Object message){
		log.error(EXCEPTION + message, e);
	}
	
}
