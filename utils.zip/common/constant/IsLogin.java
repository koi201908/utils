package com.kotei.hemap.common.constant;

public enum IsLogin { 
	YES, 
	LOGOUT, 
	NO 
}
