package com.kotei.hemap.common.constant;

import java.util.HashMap;

public class AppServiceCode{
	/** 成功 **/
	public static final String SUCCESS = "000";
	/** 失败 **/
	public static final String FAILURE = "001";
	/** 登录失败 **/
	public static final String LOGIN_ERROR = "002";
	/** 找回密码－手机不匹配 **/
	public static final String REGETPWD_PHONE_UNPAIR = "003";
	/** 找回密码－邮箱不匹配 **/
	public static final String REGETPWD_MAIL_UNPAIR = "004";
	/** 找回密码－手机未绑定 **/
	public static final String REGETPWD_PHONE_UNBIND = "005";
	/** 找回密码－邮箱未绑定 **/
	public static final String REGETPWD_MAIL_UNBIND = "006";
	/** 未找到指定商品 **/
	public static final String QUERY_ITEM_NOTHIS = "007";
	/** 修改密码－旧密码不匹配 **/
	public static final String MODIFYINFO_WRONG_PWD = "008";
	/** 绑定手机－验证码不对 **/
	public static final String BINDING_PHONE_WRONGCODE = "009";
	/** 上货失败 **/
	public static final String LOADITEM_WRONG = "010";
	/** 货道商品变更失败 **/
	public static final String CHANGE_VMSTATE_WRONG = "011";
	/** MD5验证码不匹配 **/
	public static final String WRONG_MD5 = "012";
	
	/** 订单预处理成功 **/
	public static final String ORDER_PREPARE_SUCCESS = "100";
	/** 处理失败 **/
	public static final String ORDER_FAILURE = "101";
	/** 处理成功 **/
	public static final String ORDER_SUCCESS = "102";

	public static HashMap<String, String> map = new HashMap<String, String>();
	static{
		map.put(SUCCESS, "操作成功");
		map.put(FAILURE, "操作失败");
		map.put(LOGIN_ERROR, "登录失败");
		map.put(REGETPWD_PHONE_UNPAIR, "手机号不匹配");
		map.put(REGETPWD_MAIL_UNPAIR, "邮箱地址不匹配");
		map.put(REGETPWD_PHONE_UNBIND, "未绑定手机号");
		map.put(REGETPWD_MAIL_UNBIND, "未绑定邮箱");
		map.put(QUERY_ITEM_NOTHIS, "没有该商品信息");
		map.put(MODIFYINFO_WRONG_PWD, "原始密码错误");
		map.put(BINDING_PHONE_WRONGCODE, "验证码不正确");
		map.put(CHANGE_VMSTATE_WRONG, "上货失败");
		map.put(CHANGE_VMSTATE_WRONG, "变更商品失败");
		map.put(WRONG_MD5, "不合法调用或登录超时");
		map.put(ORDER_PREPARE_SUCCESS, "订单预处理成功");
		map.put(ORDER_FAILURE, "订单预处理失败");
		map.put(ORDER_SUCCESS, "处理成功");
	};
}
