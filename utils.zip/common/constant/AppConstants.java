package com.kotei.hemap.common.constant;


public class AppConstants {

	public static final String LOGIN_USER = "vm_login_user";
	public static boolean TestMode = false;
	public static final String PROJECT_PATH = "";
	
	public static final String PAGING_VIEW = "pageView";
	
	public static final String SERVICE_VALIDATE_SUFFIX = "@KOTEI_VENDINGMANAGER";
	
	public static final String ERRMSG = "errmsg";
	
	/** 订单状态 **/
	public interface OrderStates{
		/** 等待支付中 **/
		public static final int PAYING = 41;
		/** 支付成功 **/
		public static final int PAY_SUCCESS = 42;
		/** 支付失败 **/
		public static final int PAY_ERR = 43;
		/** 出货失败 **/
		public static final int DELIVERY_ERR = 44;
		/** 已取消 **/
		public static final int PAY_RETURN = 45;
		/** 已取消 **/
		public static final int CANCELED = 46;
	}
	public interface PayResult{
		public static final String TRADE_SUCCESS = "TRADE_SUCCESS";
		public static final String TRADE_FAIL = "TRADE_FAIL";		
	}
	public interface AccountMsgType{
		public static final int MSG_KCBZ = 1; //库存不足提醒（带链接）
		public static final int MSG_TEXT = 0; //纯文本消息		
	}
	
	/**
	 * WebService功能请求key
	 * @author weih535
	 *
	 */
	public interface ServicesFuncKey{
		/*--------------------------------------------
		 * 移动App端请求定义
		 * --------------------------------------------
		 */
		/** 检查版本 **/
		public static final String UPDATE_VERSION = "UPDATE_VERSION";
		/** 用户登录 **/
		public static final String USER_LOGIN = "USER_LOGIN";
		/** 取回密码 **/
		public static final String USER_GETPWD = "USER_GETPWD";
		/** 修改密码 **/
		public static final String PWD_MODIFY = "PWD_MODIFY";
		
		/** 商品查询 **/
		public static final String ITEMS_QUERY = "ITEMS_QUERY";
		
		/** 贩卖机列表查询**/
		public static final String MACHINE_QUERY = "MACHINE_QUERY";
		/** 贩卖机库存查询**/
		public static final String MACHINE_STORAGE_QUERY = "MACHINE_STORAGE_QUERY";
		/** 贩卖机库存查询**/
		public static final String MACHINE_STORAGE_ALL_QUERY = "MACHINE_STORAGE_ALL_QUERY";
		
		/** 贩卖机销量查询**/
		public static final String MACHINE_SELL_QUERY = "MACHINE_SELL_QUERY";
		/** 商品总销量查询（该帐户所有贩卖机）**/
		public static final String MACHINE_SELL_ALL_QUERY = "MACHINE_SELL_ALL_QUERY";
		
		
		/** 发送验证码**/
		public static final String SEND_IDENTIFY = "SEND_IDENTIFY";
		/** 绑定手机**/
		public static final String MOBILE_BIND = "MOBILE_BIND";
		/** 绑定邮箱**/
		public static final String MAIL_BIND = "MAIL_BIND";
		
		/** 商品上货请求 **/
		public static final String MACHINE_CHANGE_QUERY = "MACHINE_CHANGE_QUERY";
		
		/** 登出 **/
		public static final String USER_LOGINOUT = "USER_LOGINOUT";
		
		
		/*--------------------------------------------
		 * 贩卖机shopping端请求定义
		 * --------------------------------------------
		 */
		/** 支付预处理 **/
		public static final String FUNC_VENDINGSHOP_PAY = "VENDINGSHOP_PAY";
		
		/** 出货失败时的处理 **/
		public static final String FUNC_VENDINGSHOP_DELIVERY_FAIL = "VENDINGSHOP_DELIVERY_FAIL";
		
		/** 取消订单 **/
		public static final String FUNC_VENDINGSHOP_CANCELORDER = "VENDINGSHOP_CANCELORDER";
		
		
	}
	
	public interface Msgs{
		/** 操作失败 **/
		public static final String MSG_ERROR = "操作失败!";
		
		/** 有关联数据删除失败 **/
		public static final String MSG_DELETE_ERROR = "操作失败或有关联数据不能删除!";
	}

	
	
}
