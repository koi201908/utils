package com.kotei.hemap.common.paging;

import java.util.List;

public class PagingResult<T> {
	private List<T> resultList;
	private long totalSize;
	public PagingResult(List<T> resultList, long totalRecords) {
		this.resultList = resultList;
		this.totalSize = totalRecords;
	}
	public List<T> getResultList() {
		return resultList;
	}
	public void setResultList(List<T> resultList) {
		this.resultList = resultList;
	}
	public long getTotalSize() {
		return totalSize;
	}
	public void setTotalSize(long totalSize) {
		this.totalSize = totalSize;
	}

	
	
	
}
