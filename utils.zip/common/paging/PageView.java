package com.kotei.hemap.common.paging;

import java.util.List;

public class PageView<T> {
	// 分页数据
	private List<T> records;
	// 页码开始索引和结束索引 
	private PageIndex pageindex;
	// 总页数
	private int totalpage = 1;
	// 每页显示记录数
	private int maxPageSize = 1;
	// 当前页 
	private int currentpage = 1;
	// 总记录数 
	private long totalSize;
	// 页面导航栏显示的页面索引数量
	private int pageBarsize = 10;
	
	public PageView(int pagesize, int currentpage, 	int pageBarsize) {
		this.maxPageSize = pagesize;
		this.currentpage = currentpage;
		this.pageBarsize = pageBarsize;
		
	}
	public void setPagingResult(PagingResult<T> ps){
		this.setRecords(ps.getResultList());
		this.setTotalSize(ps.getTotalSize());
	}
	public List<T> getRecords() {
		return records;
	}
	public void setRecords(List<T> records) {
		this.records = records;
	}
	public PageIndex getPageindex() {
		return pageindex;
	}
	
	/** 
	 * 计算翻页条从第几页显示到第几页
	 */
	public void setPageindex() {
		this.pageindex = PagingWebTool.getPageIndex(pageBarsize, currentpage, totalpage);
	}
	public long getTotalpage() {
		return totalpage;
	}
	public void setTotalpage() {
		/**	总页数：总记录数/pagesize的向上取整	 **/
		this.totalpage = new Long(totalSize %maxPageSize==0?totalSize/maxPageSize:totalSize/maxPageSize+1).intValue();
		setPageindex();
	}


	public int getMaxPageSize() {
		return maxPageSize;
	}
	public void setMaxPageSize(int maxPageSize) {
		this.maxPageSize = maxPageSize;
	}
	public int getCurrentpage() {
		return currentpage;
	}
	public void setCurrentpage(int currentpage) {
		this.currentpage = currentpage;
	}
	public long getTotalSize() {
		return totalSize;
	}
	public void setTotalSize(long totalrecord) {
		this.totalSize = totalrecord;
		setTotalpage();
	}
	public int getPageBarsize() {
		return pageBarsize;
	}
	public void setPageBarsize(int pageBarsize) {
		this.pageBarsize = pageBarsize;
	}

	
	
}
