package com.kotei.hemap.common.paging;

import java.util.HashMap;
import java.util.Map;

/**
 * 分页查询参数类
 * 其中的起始参数应从页面的分页请求参数计算得出
 * @author weih535
 *
 */
public class PagingParam {
	/**
	 * 分页开始条数
	 */
	private int firstResult;
	
	/**
	 * 显示多少条
	 */
	private int maxResult;
	
	@SuppressWarnings("rawtypes")
	private Map params = new HashMap(); 	// 查询参数
	private String orderColumn;
	private String orderTurn = "ASC";
	
	public PagingParam(int firstResult, int maxResult) {
		this.firstResult = firstResult;
		this.maxResult = maxResult;
	}
	
	public int getFirstResult() {
		return firstResult;
	}
	public void setFirstResult(int firstResult) {
		this.firstResult = firstResult;
	}
	public int getMaxResult() {
		return maxResult;
	}
	public void setMaxResult(int maxResult) {
		this.maxResult = maxResult;
	}

	@SuppressWarnings("rawtypes")
	public Map getParams() {
		return params;
	}

	@SuppressWarnings("rawtypes")
	public void setParams(Map params) {
		this.params = params;
	}

	public String getOrderColumn() {
		return orderColumn;
	}

	public void setOrderColumn(String orderColumn) {
		this.orderColumn = orderColumn;
	}

	public String getOrderTurn() {
		return orderTurn;
	}

	public void setOrderTurn(String orderTurn) {
		this.orderTurn = orderTurn;
	}
	
	
	
	
	
	
}
