package com.kotei.hemap.common.paging;

import com.kotei.hemap.common.AppSetting;

/**
 * @author Huwei
 */
public class PagingWebTool {
	/**
	 * 
	 * @param pageBarsize 页面导航栏显示的页面索引数量
	 * @param currenPage  当前页索引
	 * @param totalPageCount 总页数
	 * @return 记录了应该从第几页显示到第几页的索引值的PageIndex对象
	 */
	public static PageIndex getPageIndex(int pageBarsize, int currenPage, int totalPageCount){
		long startpage = currenPage-(pageBarsize%2==0? pageBarsize/2-1 : pageBarsize/2);
		long endpage = currenPage+pageBarsize/2;
		if(startpage<1){
			startpage = 1;
			if(totalPageCount>=pageBarsize) endpage = pageBarsize;
			else endpage = totalPageCount;
		}
		if(endpage>totalPageCount){
			endpage = totalPageCount;
			if((endpage-pageBarsize)>0) 
				startpage = endpage-pageBarsize+1;
			else startpage = 1;
		}
		return new PageIndex(startpage, endpage);
	}
	
	public static int checkCurrPage(int currpage, int totalpage){
		if(currpage <= 1)
			return 1;
		if(totalpage <= 1)
			return 1;
		if(currpage >= totalpage)
			return totalpage;
		return currpage;
	}
	
	/**
	 * 根据提交页面的分页请求参数（跳转页和末页数）计算出翻页查询必要参数：起始记录数和显示多少条
	 * @param topage 要跳转到的目的页
	 * @param totalpage 当前最大页
	 * @return 翻页查询参数
	 */
	public static PagingParam getPagingParam(int topage, int totalpage, int maxPageSize){
		// 校正翻页请求参数 
		if(topage <= 1)
			topage = 1;
		if(totalpage <= 1)
			totalpage = 1;
		if(topage >= totalpage)
			topage = totalpage;
		// 计算起始页
		int firstResult = (topage - 1) * maxPageSize;
		// 返回翻页参数类
		return new PagingParam(firstResult, maxPageSize);
	}

}
