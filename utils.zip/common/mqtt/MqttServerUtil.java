package com.kotei.hemap.common.mqtt;
import org.eclipse.paho.client.mqttv3.MqttException;

import com.kotei.hemap.common.utils.LogUtil;
import com.kotei.hemap.common.utils.PropUtil;


public class MqttServerUtil{
	private MqttAsyncCallBack asyncMqtt;
	
	private static MqttServerUtil mqtt = new MqttServerUtil();
	public static MqttServerUtil getInstance(){
		return mqtt;
	}
	
	private MqttServerUtil(){
		PropUtil prop = PropUtil.getInstance();
		String url = "tcp://"+prop.getProperty("MQTT_SERVER")
				+":"+prop.getProperty("MQTT_PORT");
		String clientId = "vendingmanageServer";
		boolean cleanSession = true;	
		boolean quietMode 	= false;
		try {
			asyncMqtt = new MqttAsyncCallBack(url,clientId,cleanSession, quietMode,null,null);
			LogUtil.info(LogUtil.INFO_MQTT + "new asyncMqtt..." + url);
		}catch(MqttException me) {
			// Display full details of any exception that occurs
			System.out.println("reason "+me.getReasonCode());
			System.out.println("msg "+me.getMessage());
			System.out.println("loc "+me.getLocalizedMessage());
			System.out.println("cause "+me.getCause());
			System.out.println("excep "+me);
			LogUtil.error(LogUtil.INFO_MQTT + "new asyncMqtt...");
			LogUtil.error(me);
		} catch (Throwable th) {
			LogUtil.error(th);
		}
	}	
	
	public void publish(String topic,int qos,String message){
		if(asyncMqtt.getState()==MqttAsyncCallBack.FINISH){
			asyncMqtt.setState(MqttAsyncCallBack.BEGIN);
		}
		try {
			asyncMqtt.publish(
					topic,
					qos,
					message.getBytes(PropUtil.getInstance().getProperty(
							"pushmsg_charset")));
			LogUtil.info(LogUtil.INFO_MQTT + "[pushed:]" +topic+ "==" + message);
		} catch (Throwable e) {
			LogUtil.error(e);
		}
	}
}
