package com.kotei.hemap.common.mqtt;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import com.kotei.hemap.common.exception.KtVendExceptoin;
import com.kotei.hemap.common.utils.LogUtil;
import com.kotei.hemap.common.utils.PropUtil;

public class MqttClientUtil implements MqttCallback{
	private final static short KEEP_ALIVE = 20;// 低耗网络，但是又需要及时获取数据，心跳30s
	KtMqttMsgCallback callback;
	static MqttClient client = null;

	/**
	 * @param ClientID 请使用唯一编号：手机号码或贩卖机ID
	 * @param username 默认可匿名，设为null
	 * @param pwd 默认可匿名，设为null
	 * @throws Exception
	 */
	public MqttClientUtil(String ClientID, String username, String pwd) {
		if (client == null) {
			PropUtil prop = PropUtil.getInstance();
			String serverUrl = "tcp://"+prop.getProperty("MQTT_SERVER")
					+":"+prop.getProperty("MQTT_PORT");
			System.out.println(serverUrl);
			MqttConnectOptions options = new MqttConnectOptions();
			try {
				client = new MqttClient(serverUrl, ClientID,
						new MemoryPersistence());

				options.setCleanSession(true);
				// options.setUserName(userName);
				// options.setPassword(passWord.toCharArray());
				options.setConnectionTimeout(10);
				options.setKeepAliveInterval(KEEP_ALIVE);
				client.connect(options);
			}
			catch (Exception e) {
				LogUtil.error(new KtVendExceptoin(e));
			}

			client.setCallback(this);
		}
//		subscribe("1380719_KCBZ", 2);
//		System.out.println("sub 1380719_KCBZ");
	}
	@Override
	public void connectionLost(Throwable cause) {
		LogUtil.info("connectionLost----------");
	}

	@Override
	public void deliveryComplete(IMqttDeliveryToken token) {
		LogUtil.info("deliveryComplete---------"
				+ token.isComplete());
	}

	@Override
	public void messageArrived(String topic, MqttMessage message)
			throws Exception {
		// TODO Auto-generated method stub
		callback.messageArrived(topic , message);
//		String rstMsg = new String(message.getPayload(), "GBK");
//		LogUtil.info("messageArrived----------" + "::::" + rstMsg);
		
	}
	/**
	 * 
	QoS value	bit 2	bit 1	Description
	0	0	0	至多一次	发完即丢弃	<=1
	1	0	1	至少一次	需要确认回复	>=1
	2	1	0	只有一次	需要确认回复	=1
	3	1	1	待用，保留位置
	 */
	/**
	 * 订阅消息
	 * @param topic
	 */
	public void subscribe(String topic, int qos){
		
		try {
			client.subscribe(topic, qos);
		} catch (MqttException e) {
			LogUtil.error(new KtVendExceptoin(e), topic + " subscribe Error!");
		}
	}
	
	/**
	 * 订阅消息数组
	 * @param topic
	 */
	public void subscribe(String[] topic, int[] qos){
		try {
			client.subscribe(topic, qos);
		} catch (MqttException e) {
			LogUtil.error(new KtVendExceptoin(e), topic + " subscribe Error!");
		}
	}
	
	public void disConnect(){
		LogUtil.info(LogUtil.INFO_MQTT + "Mqtt client disconnected.");
		try {
			client.disconnect();
		} catch (MqttException e) {
			LogUtil.error(new KtVendExceptoin(e), "Mqtt client disconnect Error!");
		}
	}
	public void setCallback(KtMqttMsgCallback callback) {
		this.callback = callback;
	}
	
	
}
