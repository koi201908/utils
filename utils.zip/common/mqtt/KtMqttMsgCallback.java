package com.kotei.hemap.common.mqtt;

import org.eclipse.paho.client.mqttv3.MqttMessage;

public interface KtMqttMsgCallback {
	public void messageArrived(String topic, MqttMessage message);
}
