package com.kotei.hemap.common.mqtt;

import com.kotei.hemap.common.utils.PropUtil;

public interface KtMqttConst {
	/** 批量商品更新 **/
	String TOPIC_PLSPGX = PropUtil.getInstance().getProperty("topic_Shopping.PLSPGX");
	/** 上货成功 **/
	String TOPIC_SHCG = PropUtil.getInstance().getProperty("topic_Shopping.SHCG");
	/** 支付结果 **/
	String TOPIC_ZFJG = PropUtil.getInstance().getProperty("topic_Shopping.ZFJG");
	/** 库存不足(Phone app端) **/
	String TOPIC_KCBZ = PropUtil.getInstance().getProperty("topic_Shopping.KCBZ");
	/** 广告页推送 **/
	String TOPIC_GZYXZ = PropUtil.getInstance().getProperty("topic_Machine.GZYXZ");
	int qos = Integer.parseInt(PropUtil.getInstance().getProperty("qos"));
}
