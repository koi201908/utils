package com.kotei.hemap.common.mail;

import java.net.URLEncoder;

import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;

import com.kotei.hemap.common.AppSetting;
import com.kotei.hemap.common.utils.AppUtils;
import com.kotei.hemap.common.utils.LogUtil;
import com.kotei.hemap.common.utils.PropUtil;

/**
 * @author weih535
 * commons-email是apache提供的一个开源的API，是对javamail的封装，因此在使用时要将javamail.jar加到 class path中，主要包括SimpleEmail,MultiPartEmail,HtmlEmail,EmailAttachment四个类。
 SimpleEmail:发送简单的email,不能添加附件
MultiPartEmail:文本邮件，可以添加多个附件
HtmlEmail:HTML格式邮件，同时具有MultiPartEmail类所有“功能”
EmailAttchment:附件类，可以添加本地资源，也可以指定网络上资源，在发送时自动将网络上资源下载发送。
 
发送基本文本格式邮件：
==============
SimpleEmail email = new SimpleEmail();
//smtp host 
email.setHostName("mail.test.com");
//登陆邮件服务器的用户名和密码
email.setAuthentication("test","testpassword");
//接收人
email.addTo("jdoe@somewhere.org", "John Doe");
//发送人
email.setFrom("me@apache.org", "Me");
//标题
email.setSubject("Test message");
//邮件内容
email.setMsg("This is a simple test of commons-email");
//发送
email.send();

发送文本格式，带附件邮件：
==================
//附件，可以定义多个附件对象
EmailAttachment attachment = new EmailAttachment();
attachment.setPath("e:\\1.pdf");
attachment.setDisposition(EmailAttachment.ATTACHMENT);
attachment.setDescription("Picture of John");
//
MultiPartEmail email = new MultiPartEmail();
//smtp host 
email.setHostName("mail.test.com");
//登陆邮件服务器的用户名和密码
email.setAuthentication("test","testpassword");
//接收人
email.addTo("jdoe@somewhere.org", "John Doe");
//发送人
email.setFrom("me@apache.org", "Me");
//标题
email.setSubject("Test message");
//邮件内容
email.setMsg("This is a simple test of commons-email");
//添加附件
email.attach(attachment);
//发送
email.send();
 
发送HTML格式带附件邮件：
=================
//附件，可以定义多个附件对象
EmailAttachment attachment = new EmailAttachment();
attachment.setPath("e:\\1.pdf");
attachment.setDisposition(EmailAttachment.ATTACHMENT);
attachment.setDescription("Picture of John");
//
HtmlEmail email = new HtmlEmail ();
//smtp host 
email.setHostName("mail.test.com");
//登陆邮件服务器的用户名和密码
email.setAuthentication("test","testpassword");
//接收人
email.addTo("jdoe@somewhere.org", "John Doe");
//发送人
email.setFrom("me@apache.org", "Me");
//标题
email.setSubject("Test message");
//邮件内容
email.setHtmlMsg("This is a simple test of commons-email");
//添加附件
email.attach(attachment);
//发送
 * email.send();
 *
 */
public class MailUtil {
	public static final String ENCODEING = "UTF-8"; 
	//构造邮箱绑定验证邮件
	public static Mail getValidateMail(String mailto, String userid){
		Mail mail = new Mail();
		PropUtil propUtil = PropUtil.getInstance();
		mail.setHost(propUtil.getProperty("Mail_SMTP"));
		mail.setUsername(propUtil.getProperty("Mail_Address"));
		mail.setPassword(propUtil.getProperty("Mail_Password"));
		mail.setSender(propUtil.getProperty("Mail_Address"));
		mail.setName("Mail_MyName");
		mail.setSubject(propUtil.getProperty("Mail_bindMail_subject"));
		mail.setReceiver(mailto);
		
		String validatecode = AppUtils.createRandom(true, 6);
		AppUtils.saveValidateKey(userid, validatecode);
		
		String linkString = AppSetting.APP_URL + propUtil.getProperty("Mail_bindMail_link") + userid
				+ "&validatecode=" + validatecode;
			
		mail.setMessage(propUtil.getProperty("Mail_bindMail_content")
				+ "<a href='" + URLEncoder.encode(linkString) + "'>" 
				+ linkString + "</a>");
		return mail;
	}
	//构造取回密码邮件
	public static Mail getRtnPwdMail(String mailto, String userid){
		Mail mail = new Mail();
		PropUtil propUtil = PropUtil.getInstance();
		mail.setHost(propUtil.getProperty("Mail_SMTP"));
		mail.setUsername(propUtil.getProperty("Mail_Address"));
		mail.setPassword(propUtil.getProperty("Mail_Password"));
		mail.setSender(propUtil.getProperty("Mail_Address"));
		mail.setName("Mail_MyName");
		mail.setSubject(propUtil.getProperty("Mail_GetPwd_subject"));
		mail.setReceiver(mailto);
		mail.setMessage(propUtil.getProperty("Mail_GetPwd_content"));
		return mail;
	}
	
	public static boolean send(Mail mail) throws EmailException {
		// 发送email
		HtmlEmail email = new HtmlEmail();
		// 这里是SMTP发送服务器的名字：163的如下："smtp.163.com"
		email.setHostName(mail.getHost());
		// 字符编码集的设置
		email.setCharset(ENCODEING);
		// 收件人的邮箱
		email.addTo(mail.getReceiver());
		// 发送人的邮箱
		email.setFrom(mail.getSender(), mail.getName());
		// 如果需要认证信息的话，设置认证：用户名-密码。分别为发件人在邮件服务器上的注册名称和密码
		email.setAuthentication(mail.getUsername(), mail.getPassword());
		// 要发送的邮件主题
		email.setSubject(mail.getSubject());
		// 要发送的信息，由于使用了HtmlEmail，可以在邮件内容中使用HTML标签
		email.setMsg(mail.getMessage());
		// 发送
		email.send();
		LogUtil.debug(mail.getSender() + " 发送邮件到 " + mail.getReceiver());
		return true;
	}
	
	
}
