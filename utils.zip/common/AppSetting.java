package com.kotei.hemap.common;

import java.util.HashMap;

import com.kotei.hemap.persistence.entity.Account;

/**
 * 可配置的应用程序常量
 * @author Administrator
 *
 */
public class AppSetting {
	/**
	 * 分页单页显示的默认记录数，程序起动时根据配置参数自动设置
	 * 页面请求中修改后以修改值显示
	 */
	public static int pagesize = 10;

	/**
	 * 分页导航条显示的可选择的页面数，程序起动时根据配置参数自动设置
	 */
	public static int pageBarSize = 10;

	/**
	 * 商品图片保存路径
	 */
	public static String IMAGE_ITEM_PATH = "images/itemImgs";
	/**
	 * 用户头像图片保存路径
	 */
	public static String IMAGE_ACCOUNTPHOTO_PATH = "images/userPhotos";
	/**
	 * 商品图片小图片后缀名
	 */
	public static String IMAGE_SMALL_SUFFIX = "_small";
	/**
	 * 商品图片小图片后缀名
	 */
	public static int IMAGE_SMALLI_DEFAULTWIDTH = 140;

	public static String PROJECT_PATH = "";

	/** web应用程序URL全路径 **/
	public static String APP_URL = "";

	/** phone app端已登录用户 **/
	public static HashMap<String, Account> loginedAccounts = new HashMap<String, Account>();
	
	public static boolean isMqttStarted = false;

	public static int getPayType(int type){
//		01-	支付宝扫码支付
//		02-	微信支付
//		03-	校园卡
//		04-	武汉通
		int rstType = 0;
		switch (type) {
		case 1: //支付宝
			rstType = 51;			
			break;
		case 2: //微信
			rstType = 52;			
			break;
		case 3: //校园卡
			rstType = 53;			
			break;
		case 4: //武汉通
			rstType = 54;			
			break;

		default:
			break;
		}
		return rstType;
		
	}
}
